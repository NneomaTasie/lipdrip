# Lip Drip Website

Official website for **Lip Drip**, a luxury lip care brand. Built with HTML/CSS and deployed using GitHub Pages.